import './assets/css/App.css';
import { BrowserRouter , Route, Routes } from 'react-router-dom';
//import Head from './components/header/head';
import Header from './components/header/header';
import Main from './components/Home/main';
import Login from './components/stuLogin';
import Footer from './components/Footer/footer';

function App() {

  return (
   <BrowserRouter>
      <Header/>
        <Routes>
          <Route>
            <Route path="/" element={<Main/>} />
            <Route path="/Login" element={<Login/>} />
          </Route>
        </Routes>
      <Footer/>
   </BrowserRouter>
  )
}

export default App
