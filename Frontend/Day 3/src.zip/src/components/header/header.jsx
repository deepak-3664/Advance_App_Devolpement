import { Link } from "react-router-dom"
import "../../assets/css/header.css"
import Head from "./head"
import { CgProfile } from "react-icons/cg";

const Header = () => {

  return (
    <>
      <Head />
      <header>
        <nav className='flexSB'>
          <ul className="flexSB">
           <li> <Link to='/'>Home</Link></li>
           <li><Link to="/Login">About</Link></li>
           <li><Link to="/Login">Courses</Link></li>
           <li><Link to="/Login">Exam</Link></li>
          </ul>
          <div className='start'>
            <div className='button'>
                < CgProfile className="icon2"/>
                </div>
          </div>
        </nav>
      </header>
    </>
  )
}

export default Header