import Carde from "./college"
import Main from "./main"

const Home = () => {
    return (
      <>
        <Main />
        <Carde/>
      </>
    )
  }
  
  export default Home